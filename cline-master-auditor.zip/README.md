README for Master Auditor
