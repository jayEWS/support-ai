# ARCHITECTURE STANDARDS
Analyze coupling, scalability, and domain separation.
