# MASTER AUDITOR EXECUTION RULES
1. Recursion 2. Deep Dive 3. No Mercy 4. Auto-Patch
